#include <stdint.h>


int16_t ex02_testXt[] = {
  35,
  27,
  104,
  100,
  77,
  64,
  225,
  104,
  79,
  201,
  216,
  179,
  246,
  31,
  114,
  207,
  249,
  50,
  190,
  54,
};
int ex02_testXt_size = sizeof(ex02_testXt)/sizeof(ex02_testXt[0]);


int16_t ex02_testHp[] = {
  101,
  192,
  197,
  14,
  65,
  246,
  145,
  148,
  65,
  115,
  69,
  35,
  72,
  142,
  134,
  134,
};
int ex02_testHp_size = sizeof(ex02_testHp)/sizeof(ex02_testHp[0]);


int16_t ex02_IaFxp[] = {
  4143,
  6427,
  4467,
  6316,
  4753,
  5679,
  6657,
  5405,
  5464,
  5827,
  6453,
  4932,
  7547,
  5998,
  5488,
  5198,
};
int ex02_IaFxp_size = sizeof(ex02_IaFxp)/sizeof(ex02_IaFxp[0]);


int16_t ex02_FaFxp[] = {
  4800,
  5025,
  4288,
  7511,
  5494,
  5553,
  6501,
  5019,
  6962,
  3912,
  5468,
  4775,
  4345,
  4147,
  6079,
  6238,
};
int ex02_FaFxp_size = sizeof(ex02_FaFxp)/sizeof(ex02_FaFxp[0]);


int16_t ex02_OaFxp[] = {
  5772,
  5130,
  6670,
  5073,
  3852,
  5774,
  6565,
  6968,
  6221,
  3672,
  4345,
  4419,
  4395,
  6339,
  4762,
  4724,
};
int ex02_OaFxp_size = sizeof(ex02_OaFxp)/sizeof(ex02_OaFxp[0]);


int16_t ex02_CaFxp[] = {
  5992,
  6827,
  6815,
  4437,
  4775,
  5306,
  6202,
  5784,
  4233,
  7231,
  5148,
  5312,
  6568,
  5206,
  4760,
  5888,
};
int ex02_CaFxp_size = sizeof(ex02_CaFxp)/sizeof(ex02_CaFxp[0]);